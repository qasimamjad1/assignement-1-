﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rd = new Random();                         //Random list created
            List<int> randomList =new List<int>();
            for (int i=0;i<5;i++)
            {
                randomList.Add(rd.Next(1, 999));
            }
            Console.WriteLine("Random List Generted By Computer: ");
            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine(randomList[j]);
            }
            
            randomList.Sort();
            randomList.Reverse();
            Console.WriteLine("Largest Number  Generted By Computer: "+randomList[0]);
            Console.WriteLine("Second Largest Number  Generted By Computer: " + randomList[1]);

            Console.ReadLine();

        }
    }
}
