﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Program
    {
        static bool isPrime(int no)                        //Prime number function
        {
            int a;
            int flag = 0;
            for(a=2;a<no/2;a++)
            {
                if(no%a==0)
                {
                    flag=1;
                    break;
                }
            }
            if(flag==1)
                return false;    //not a prime number
            else
                return true;         // prime number

        }
        
        static void Main(string[] args)
        {
            int Prime=0;
            Random rd = new Random();                         //Random list created
            List<int> randomList =new List<int>();
            for (int i=0;i<20;i++)
            {
                randomList.Add(rd.Next(1, 999));
            }
            Console.WriteLine("Random List Generted By Computer: ");
            for (int j = 0; j < 20; j++)
            {
                Console.WriteLine(randomList[j]);
            }
            Console.WriteLine("Length of Random List : " + randomList.Count);
            //Checking for prime numbers and removing 
            for (int i = 0; i < 5; i++)
            {
                if (isPrime(randomList[i]))
                {
                    randomList[i] = randomList[i + 1];
                    Prime++;
                }


            }

            Console.WriteLine("Array without Prime Number is : ");             // List with Prime Number
                for (int j = 0; j < randomList.Count; j++)
                {
                    Console.WriteLine(randomList[j]);
                }
                Console.WriteLine("Total prime NUmbers Found: " + Prime);
            Console.ReadLine();
        }
    }
}
