﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
                    
            int i, j=0;
            int[] oldArray = new int[] { 1, 0, 3, 9, 5, 0, 6, 0, 2, 4, 9, 3, 4 };   //Array created
            int num = oldArray.Length;
            //array size
            Console.WriteLine("Given array is: ");                    //Printing original array
            for (i = 0; i < num; i++)
            {
                Console.WriteLine(oldArray[i]);
            }
            for (i = 0; i < num; i++)                               //Delete duplicates by storing next value of duplicate in previous duplicate(we can also store data in array from user and same logic can be applied
            {
                for (j = i + 1; j < num; j++)
                {
                    if (oldArray[i] == oldArray[j])
                    {
                        for (int k = j; k < num-1; k++)
                        {
                            oldArray[k] = oldArray[k+ 1];
                        }
                        num--;
                        j--;
                    }
                }
            }
            Console.WriteLine("New array After deleting duplicates: ");            //Printing final
            for (int n = 0; n < num; n++)
            {
                Console.WriteLine(oldArray[n]);

            }
            Console.ReadLine();

                Console.ReadLine();
        }
    }
}
