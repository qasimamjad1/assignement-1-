﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] randomList=new int[13]{ 1, 0, 3, 0, 5, 0, 6, 0, 2, 4, 4, 0, 4 };   //Array created
            int L = randomList.Count();
            int[] newList = new int[L];
            
            
            int pos = 0;                             // initial position

            for (int a = 0; a < L; a++)                    //iterating zeroes in new list
            {
                
                if (randomList[a] != 0)
                {
                    newList[pos] = randomList[a];
                    pos++;
                }
            }

                

                Console.WriteLine("New List  ");  //printing new liss out
                for (int k = 0; k < L; k++)
                {
                    Console.WriteLine(newList[k]);

                }
                Console.ReadLine();
            
        }
        
    }
}
