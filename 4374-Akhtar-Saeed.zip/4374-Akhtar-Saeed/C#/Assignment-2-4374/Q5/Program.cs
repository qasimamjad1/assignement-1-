﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[] { 1, 0, 3, 9, 5, 0, 6, 0, 2, 4, 9, 3, 4 };   //random list
            int L = arr.Length;
            int[] frequency = new int[L];  //Storing frequencies 
            int ctr = -1;
            for(int i=0; i<L;i++)
            {
                int count = 1;
                for(int j=i+1;j<L;j++)
                {
                    if (arr[i]==arr[j])
                    {
                        count++; // to avoid same element again

                        frequency[j] = ctr;

                    }
                }
                if (frequency[i] != ctr)
                    frequency[i] = count;
            }
            for (int  i=0; i<frequency.Length;i++)
            {
                if (frequency[i] != ctr)
                    Console.WriteLine("Elements:  {0}  , Frequency:   {1}  ", arr[i], frequency[i]);           // displaying frequency and elemebnt in array  
            }
            Console.ReadLine();

        }
    }
}
