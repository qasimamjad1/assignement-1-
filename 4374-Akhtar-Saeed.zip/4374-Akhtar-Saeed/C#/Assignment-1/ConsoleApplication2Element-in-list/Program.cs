﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2Element_in_list
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number for Multiplication Table: ");
            int num = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i < 11; i++)
            {
                int x = num * i;
                Console.WriteLine("{0} * {1} = {2}", num, i, x );
            }
            Console.ReadLine();
        }
    }
}
