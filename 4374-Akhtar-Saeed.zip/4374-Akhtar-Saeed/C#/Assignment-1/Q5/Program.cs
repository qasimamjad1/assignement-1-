﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<int> list1 = new List<int>();   //list of numbers
            for (int i = 1; i < 232; i++)
            {
                list1.Add(i);
               
            }
            Console.WriteLine(list1.Max()); //built-in function for max number in list
            Console.ReadLine();
            

        
        }
   
    }
}
