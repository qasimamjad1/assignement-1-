﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationEven_Odd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ENter  number to point out odd even");
            int num = Convert.ToInt32(Console.ReadLine());
            int r = num % 2;
          if (r==1)
             {
                 Console.WriteLine("Entered number {0} is odd", num);
             }
             else
             {
                 Console.WriteLine("Entered number {0} is even", num);
             }
 


       
            
            Console.ReadLine();

        }
    }
}
