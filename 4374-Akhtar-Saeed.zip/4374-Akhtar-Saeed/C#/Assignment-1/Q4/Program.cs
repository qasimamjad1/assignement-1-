﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list1 = new List<int>();   //list of even number leass then 232
            for(int i =0;i<232;i++)
            {
                list1.Add(i);
                i++;
            }
            Console.WriteLine("Enter number less than 232");
            int check = Convert.ToInt32(Console.ReadLine());
            if (list1.Contains(check))
            {
                Console.WriteLine("Number is Present in Given LIst");

            }
            else
            {
                Console.WriteLine("ENtered Number is Not Present in given list");

            }


            Console.ReadLine();

            }
        

                
            
        }
    }

