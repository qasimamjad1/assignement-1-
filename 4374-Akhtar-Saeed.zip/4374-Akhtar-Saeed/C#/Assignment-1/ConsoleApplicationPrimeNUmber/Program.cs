﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationPrimeNUmber
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, d, x;
            int test = 0;
            Console.WriteLine("Enter a number to check Whether its Prime or NOt  ");
         num = Convert.ToInt32(Console.ReadLine());
         d = num / 2;
        for (int i = 2; i < d; i++ )
        {
            x = num % i;
            if(x==0)
            {
                Console.WriteLine("Given number is not Prime Number");
                test=1;
                    break;

            }
        }
            if(test==0)
            {
                Console.WriteLine("Given number is Prime Number");
            }
           
        Console.ReadLine();



        }
    }
}
