﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bonus
{
    class Program
    {
         public  static string Reverse (string revWord)
        {
            int size = 0;
            size = revWord.Length - 1;
             
            while (size >= 0)
            {
                for (int i = 0; i <= size; i++)
                {
                    char x = revWord[size];
                }
                
                size--;
            }
             return revWord;
         }
        static void Main(string[] args)
        {
            string word;
            Console.Write("Input the Word for Panewmadic check : ");  //user input
            word = Console.ReadLine();
            string check=Reverse(word);
            if (string.Equals(word, check))
            {
                Console.WriteLine("Input string is palindrome ");
            }
            else
            {
                Console.WriteLine("Input string is not palindrome");
            }

            Console.ReadLine();
        }

             
            

        }    
        }
        

