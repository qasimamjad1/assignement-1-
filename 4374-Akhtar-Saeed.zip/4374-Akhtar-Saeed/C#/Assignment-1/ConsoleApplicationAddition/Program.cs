﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationAddition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number for Addition");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number for Addition");
            int b = Convert.ToInt32(Console.ReadLine());
            int c = a + b;
            Console.WriteLine("Sum of {0} and {1} is : {2} " ,a,b,c);
            Console.ReadLine();
        }
    }
}
