﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q7
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list1 = new List<int>();   //list of numbers
            for (int i = 0; i < 232; i++)
            {
                list1.Add(i);
            }
            for (int j = 1; j < 232; j=j+2)
            {
                Console.Write(list1[j] + " ");
            }
            Console.ReadLine();
        }
    }
}
