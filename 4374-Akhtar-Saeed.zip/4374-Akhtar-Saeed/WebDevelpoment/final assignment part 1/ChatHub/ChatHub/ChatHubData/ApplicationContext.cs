﻿using ChatHub.Models;
using Microsoft.EntityFrameworkCore;

namespace ChatHub.ChatHubData
{
    public class ApplicationContext:DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options) { }
        public DbSet<Customer> Customers { get; set; }
    }
}
