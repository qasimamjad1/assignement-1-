﻿using ChatHub.ChatHubData;
using ChatHub.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;

namespace ChatHub.Controllers
{
    public class InstructorController : Controller
    {
        private readonly ApplicationContext context;

        public InstructorController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            var result = context.Customers.ToList();
            return View(result);
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult NewPost(Customer model)
        {
            if (ModelState.IsValid)
            {
                var newpost = new Customer()
                {
                    text = model.text
                };
                context.Customers.Add(newpost);
                context.SaveChanges();
                return RedirectToAction("Index");

            }
            else
            {
                TempData["Error"] = "Invalid!";
                return View(model);
            }
        }
        [HttpPost]
        public IActionResult Login(Customer model)
        {
            if (ModelState.IsValid)
            {
                var input2 = context.Customers.Where(x => x.username == model.username).SingleOrDefault();
                if (input2 != null)
                {
                    bool isvalid = (input2.username == model.username && input2.password == model.password);
                    if (isvalid)
                    {
                        var id = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.username) },
                                       CookieAuthenticationDefaults.AuthenticationScheme);
                        var pclaim = new ClaimsPrincipal(id);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, pclaim);
                        HttpContext.Session.SetString("username", model.username);
                        return RedirectToAction("Index", "Instructor");
                    }
                    else
                    {
                        TempData["ErrorPassword"] = "Password Invalid!";
                        return View(model);
                    }
                }
                else
                {
                    TempData["ErrorUsername"] = "Username Invalid";
                    return View(model);
                }
            }
            else
            {
                return View(model);

            }
        }
        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Instructor");
        }
    }
}


    

