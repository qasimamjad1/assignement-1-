﻿using ChatHub.ChatHubData;
using ChatHub.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ChatHub.Controllers
{
    public class CandidateController : Controller
    {
        private readonly ApplicationContext context;

        public CandidateController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            var result = context.Customers.ToList();
            return View(result);
        }

        
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(Customer model)
        {
            if (ModelState.IsValid)
            {
                var input1 = context.Customers.Where(e => e.username == model.username).SingleOrDefault();
                if (input1 != null)
                {
                    bool isvalid = (input1.username == model.username && input1.password == model.password);
                    if (isvalid)
                    {
                        var id= new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.username) },
                            CookieAuthenticationDefaults.AuthenticationScheme);
                        var pclaim = new ClaimsPrincipal(id);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, pclaim);
                        HttpContext.Session.SetString("username", model.username);
                        return RedirectToAction("Index", "Candidate");
                    }
                    else
                    {
                        TempData["ErrorPassword"] = "Password Invalid!";
                        return View(model);
                    }
                }
                else
                {
                    TempData["ErrorUsername"] = "Username Invalid!";
                    return View(model);
                }
            }
            else
            {
                return View(model);

            }
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Customer model)
        {
            if (ModelState.IsValid)
            {
                var newclient = new Customer()
                {
                    fullname = model.fullname,
                    username = model.username,
                    email = model.email,
                    password = model.password
                };
                context.Customers.Add(newclient);
                context.SaveChanges();
                return RedirectToAction("Index");

            }
            else
            {
                TempData["Error"] = "Invalid!";
                return View(model);
            }
        }

        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Candidate");
        }
    }
}
