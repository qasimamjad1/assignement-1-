﻿using ChatHub.ChatHubData;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using ChatHub.Models;
using System.Linq;

namespace ChatHub.Controllers
{
    public class SuperInstructorController : Controller
    {
        private readonly ApplicationContext context;


        public SuperInstructorController(ApplicationContext context)
        {
            this.context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Customer model)
        {
            if (ModelState.IsValid)
            {
                var input3 = context.Customers.Where(e => e.username == model.username).SingleOrDefault();
                if (input3 != null)
                {
                    bool isvalid = (input3.username == model.username && input3.password == model.password);
                    if (isvalid)
                    {
                        var id = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, model.username) },
                             CookieAuthenticationDefaults.AuthenticationScheme);
                        var pclaim= new ClaimsPrincipal(id);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, pclaim) ;
                        HttpContext.Session.SetString("username", model.username);
                        return RedirectToAction("Index", "SuperInstructor");
                    }
                    else
                    {
                        TempData["ErrorPassword"] = "Password Invalid!";
                        return View(model);
                    }
                }
                else
                {
                    TempData["ErrorUsername"] = "Username Invalid";
                    return View(model);
                }
            }
            else
            {
                return View(model);

            }
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Customer model)
        {
            if (ModelState.IsValid)
            {
                var newcustomer = new Customer()
                {
                    fullname = model.fullname,
                    username = model.username,
                    email = model.email,
                    password = model.password
                };
                context.Customers.Add(newcustomer);
                context.SaveChanges();
                return RedirectToAction("Index", "Instructor");

            }
            else
            {
                TempData["Error"] = "Invalid!";
                return View(model);
            }
        }
    }
}
