﻿using System;

namespace q7
{
    class Program
    {
        static void Main(string[] args)
        {
            int b;
            Console.WriteLine("Enter your number : ");
            int a = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i <= 12; i++)
            {
                b = a * i;
                Console.WriteLine(b);
            }
            Console.ReadKey();
        }
    }
}
