﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the Size of an array: ");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements Please " );
            

            int[] a = new int[size];

            for (int i = 0; i < size; i++)
            {
                Console.Write(i + 1 + "  element is:");
                a[i] = int.Parse(Console.ReadLine());

            }

            Console.WriteLine("Your Array is :");
            for (int i = 0; i < size ; i++)
            {
                Console.Write(a[i]+ "   ");

            }
            Console.ReadKey();
        }

    }
}
