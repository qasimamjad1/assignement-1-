﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q3
{
    class Program
    {
        static void Main()
        {
            int a, b;
            Console.Write("Enter first number:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter second number:");
            b = Convert.ToInt32(Console.ReadLine());

            int c = a + b;
            Console.WriteLine("Total :" + c);

            Console.ReadKey();


        }
    }
}
