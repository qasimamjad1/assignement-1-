﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number to be squared :");
            int a = Convert.ToInt32 (Console.ReadLine());
            int b = a * a;
            Console.WriteLine("The Square is :" + b);
            Console.ReadKey();
        }
    }
}
