﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number : ");
            int a = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= a+1; i++)
            {
                if (a % i != 0)
                {
                    Console.WriteLine(i);
                }

            }
            Console.ReadKey();
        }
    }
}
