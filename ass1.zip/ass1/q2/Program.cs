﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter your name :");
            string a = Console.ReadLine();
            Console.WriteLine("Hello  " + a);



            Console.ReadKey();


        }
    }
}
