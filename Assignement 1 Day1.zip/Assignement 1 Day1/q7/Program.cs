﻿using System;

namespace q7
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter the numberfor your table: \n");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            for (int val = 1; val <= 12; val++)
            {
              int   b = a * val;
                Console.WriteLine(b);
                ; 
            }
            Console.ReadKey();
        }
    }
}
