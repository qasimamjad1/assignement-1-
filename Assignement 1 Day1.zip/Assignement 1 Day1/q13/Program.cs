﻿using System;

namespace q13
{
    class Program
    {
        static void Main()
        {
            int[] array = new int[5]; // Array declared
            int i;

            Console.Write("Input 5 elements in the array:\n");
            for (i = 0; i < 5; i++)
            {
                Console.Write("element - {0} : ", i);
                array[i] = Convert.ToInt32(Console.ReadLine());//array input 
            }

            Console.Write("\nThank you for the array.\n");

            int smallest = FindSmallestNumber(array); // Call function to find the smallest number
            Console.WriteLine("Smallest number: " + smallest);
           
            int largest = FindLargestNumber(array); // Call function to find the largest number
            Console.WriteLine("Largest number: " + largest);

            Console.ReadKey();
        }

        static int FindSmallestNumber(int[] array)
        {
            int smallest = array[0]; // Assume the first element is the smallest

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < smallest)
                {
                    smallest = array[i]; // Update smallest if a smaller number is found
                }
            }

            return smallest;
        }

        static int FindLargestNumber(int[] array)
        {
            int largest = array[0]; // Assume the first element is the largest

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > largest)
                {
                    largest = array[i]; // Update largest if a larger number is found
                }
            }

            return largest;
        }
    }
}
