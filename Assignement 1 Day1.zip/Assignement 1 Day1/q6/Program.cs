﻿using System;

namespace q6
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("\nEnter the number n: ");
            int a = Convert.ToInt32(Console.ReadLine());//input to a

            int val, sum=0;
            for (val = 1; val <= a; val++)
            {
                sum += val;//the value is added to sum every time
            }

            Console.WriteLine(sum);
            Console.ReadKey();      }
    }
}
