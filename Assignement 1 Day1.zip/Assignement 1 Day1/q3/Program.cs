﻿using System;

namespace q3
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("\nEnter the first number to add : ");//cin
            int a = Convert.ToInt32(Console.ReadLine());//ToInt32 will covert the input to 32 bits 
            Console.WriteLine("\nEnter the second number to add : ");//cin
            int b = Convert.ToInt32(Console.ReadLine());
            int c; //integer declared 

            c = a + b;//the sum is stored in the C 
            Console.WriteLine("\nSum = {0}", c);//dispalyed the result of c
            Console.ReadKey();//clearscreen
        }
    }
}
