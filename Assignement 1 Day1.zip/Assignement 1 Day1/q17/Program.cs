﻿using System;

namespace q17
{
    class Program
    {
        static void Main()
        {
            int[] arr = new int[5];//array declared
            int a;

            Console.Write("Input 5 elements in the array:\n");
            for (int i = 0; i < 5; i++)
            {
                Console.Write("element - {0} : ", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            Array.Sort(arr);

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }

        }
    }
}

