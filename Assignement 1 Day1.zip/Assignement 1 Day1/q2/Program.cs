﻿using System;

namespace q2
{
    class Program
    {
        static void Main()
        {
            string testString;// string declared 
            Console.Write("Enter Your Name Please :  - ");//displayed 
            testString = Console.ReadLine();//input taken 
            Console.WriteLine("Hello  '{0}'", testString);//displayed and testString will display the input 
            Console.ReadKey();//to clear the screen
        }
    }
}
