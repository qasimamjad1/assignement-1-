﻿using System;

namespace q11
{
    class Program
    {
        static void Main()
        {
            int[] arr = new int[5];//array declared
            int i;

            Console.Write("Input 5 elements in the array:\n");
            for (i = 0; i < 5; i++)
            {
                Console.Write("element - {0} : ", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.Write("\nThank you for the array.");
            Console.Write("\nPlease enter the number you want to check: ");
            int a = Convert.ToInt32(Console.ReadLine());

            bool found = false;
            for (i = 0; i < 5; i++)
            {
                if (arr[i] == a)
                {
                    found = true;
                    break;
                }
            }

            if (found)
            {
                Console.Write("Yes, it exists in the array.");
            }
            else
            {
                Console.Write("\nThere is no such number in the array.");
            }

            Console.Write("\n");
            Console.ReadKey();
        }
    }
}