﻿using System;
using System.Collections.Generic;

public class BankAccount
{
    public int AccountNumber { get; set; }
    public string AccountHolderName { get; set; }
    public decimal Balance { get; set; }

    public BankAccount(int accountNumber, string accountHolderName, decimal balance)
    {
        AccountNumber = accountNumber;
        AccountHolderName = accountHolderName;
        Balance = balance;
    }

    public virtual void Deposit(decimal amount)
    {
        Balance += amount;
        Console.WriteLine($"Deposited {amount:C}. New balance: {Balance:C}");
    }

    public virtual void Withdraw(decimal amount)
    {
        if (Balance >= amount)
        {
            Balance -= amount;
            Console.WriteLine($"Withdrawn {amount:C}. New balance: {Balance:C}");
        }
        else
        {
            Console.WriteLine("Insufficient funds. Withdrawal canceled.");
        }
    }

    public void DisplayAccountInfo()
    {
        Console.WriteLine($"Account Number: {AccountNumber}");
        Console.WriteLine($"Account Holder: {AccountHolderName}");
        Console.WriteLine($"Balance: {Balance:C}");
    }
}

public class SavingsAccount : BankAccount
{
    public decimal InterestRate { get; set; }

    public SavingsAccount(int accountNumber, string accountHolderName, decimal balance, decimal interestRate)
        : base(accountNumber, accountHolderName, balance)
    {
        InterestRate = interestRate;
    }

    public override void Deposit(decimal amount)
    {
        decimal interest = amount * InterestRate;
        Balance += amount + interest;
        Console.WriteLine($"Deposited {amount:C} with interest. New balance: {Balance:C}");
    }
}

public class CheckingAccount : BankAccount
{
    public CheckingAccount(int accountNumber, string accountHolderName, decimal balance)
        : base(accountNumber, accountHolderName, balance)
    {
    }

    public override void Withdraw(decimal amount)
    {
        if (Balance >= amount)
        {
            Balance -= amount;
            Console.WriteLine($"Withdrawn {amount:C}. New balance: {Balance:C}");
        }
        else
        {
            Console.WriteLine("Insufficient funds. Withdrawal canceled.");
        }
    }
}

public class Bank
{
    public List<BankAccount> BankAccounts { get; set; }

    public Bank()
    {
        BankAccounts = new List<BankAccount>();
    }

    public void AddAccount(BankAccount account)
    {
        BankAccounts.Add(account);
        Console.WriteLine($"Account {account.AccountNumber} added to the bank.");
    }

    public void DepositToAccount(int accountNumber, decimal amount)
    {
        BankAccount account = BankAccounts.Find(a => a.AccountNumber == accountNumber);
        if (account != null)
        {
            account.Deposit(amount);
        }
        else
        {
            Console.WriteLine($"Account {accountNumber} not found.");
        }
    }

    public void WithdrawFromAccount(int accountNumber, decimal amount)
    {
        BankAccount account = BankAccounts.Find(a => a.AccountNumber == accountNumber);
        if (account != null)
        {
            account.Withdraw(amount);
        }
        else
        {
            Console.WriteLine($"Account {accountNumber} not found.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Bank bank = new Bank();

        SavingsAccount savingsAccount = new SavingsAccount(1001, "John Doe", 5000, 0.05m);
        CheckingAccount checkingAccount = new CheckingAccount(2001, "Jane Smith", 3000);

        bank.AddAccount(savingsAccount);
        bank.AddAccount(checkingAccount);

        bank.DepositToAccount(1001, 1000);
        bank.WithdrawFromAccount(2001, 2000);
        bank.WithdrawFromAccount(1001, 6000);

        Console.ReadKey();
    }
}
